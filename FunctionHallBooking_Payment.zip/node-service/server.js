const express = require("express");

const app = express();
app.use(express.json());

app.get("/api/health", (req, res) => {
    res.json({
        service: "Function Hall Node Service",
        status: "running"
    });
});

app.post("/api/payment-check", (req, res) => {
    res.json({
        paymentStatus: "DEMO_SUCCESS",
        message: "Demo payment check completed."
    });
});

app.listen(3000, () => {
    console.log("Node service running on http://localhost:3000");
});
